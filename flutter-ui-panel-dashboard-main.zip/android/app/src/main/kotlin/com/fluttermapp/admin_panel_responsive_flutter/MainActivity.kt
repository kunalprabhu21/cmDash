package com.fluttermapp.admin_panel_responsive_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
