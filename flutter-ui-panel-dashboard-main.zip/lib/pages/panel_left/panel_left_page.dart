
import 'package:admin_panel_responsive_flutter/models/User.dart';
import 'package:admin_panel_responsive_flutter/users.dart';
import 'package:flutter/material.dart';
import 'package:admin_panel_responsive_flutter/constants.dart';
import 'package:google_fonts/google_fonts.dart';

class Todo {
  String name;
  bool enable;
  Todo({this.enable = true, required this.name});
}

class PanelLeftPage extends StatefulWidget {
  @override
  _PanelLeftPageState createState() => _PanelLeftPageState();
}

class _PanelLeftPageState extends State<PanelLeftPage> {
  int? sortColumnIndex;
  bool isAscending = false;
  final columns = ['id', 'Department', 'Open','Completed','Pending','Closed'];
  late List<Records> users;

  @override
  void initState() {
    super.initState();
    this.users = List.of(allUsers);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text("Chief Minister's File Tracker",style: Theme.of(context).textTheme.headline1,),
                  Text("Last Updated On: 26 May 2022",style: Theme.of(context).textTheme.headline2,)
                ],
              ),
              SizedBox(height: 20,),
              Container(
                child: SingleChildScrollView(
                  child: Row(
                    children: [
                      Expanded(
                        child: Container(
                          padding: EdgeInsets.symmetric(vertical: 20),
                        margin: EdgeInsets.only(right: Constants.cardMargin),
                            decoration: BoxDecoration(
                                color: Constants.cardColorOpen,
                                borderRadius: BorderRadius.all(Radius.circular(Constants.cardBorders))
                            ),
                          child: Column(
                            children: [
                              Text("77",style: Theme.of(context).textTheme.bodyText1,),
                              Text("Open",style: Theme.of(context).textTheme.bodyText2,),
                            ],
                          )
                        ),
                      ),

                      Expanded(
                        child: Container(
                            padding: EdgeInsets.symmetric(vertical: 20),
                            margin: EdgeInsets.symmetric(horizontal: Constants.cardMargin),

                            decoration: BoxDecoration(
                                color: Constants.cardColorinTime,
                                borderRadius: BorderRadius.all(Radius.circular(Constants.cardBorders))
                            ),
                          child: Column(
                            children: [
                              Text("45",style: Theme.of(context).textTheme.bodyText1,),
                              Text("In Time",style: Theme.of(context).textTheme.bodyText2,),
                            ],
                          )
                        ),
                      ),

                      Expanded(
                        child: Container(
                            padding: EdgeInsets.symmetric(vertical: 20),
                            margin: EdgeInsets.symmetric(horizontal: Constants.cardMargin),
                            decoration: BoxDecoration(
                                color: Constants.cardColorlapsed,
                                borderRadius: BorderRadius.all(Radius.circular(Constants.cardBorders))
                            ),
                          child: Column(
                            children: [
                              Text("0",style: Theme.of(context).textTheme.bodyText1,),
                              Text("Lapsed",style: Theme.of(context).textTheme.bodyText2,),
                            ],
                          )
                        ),
                      ),

                      Expanded(
                        child: Container(
                            padding: EdgeInsets.symmetric(vertical: 20),
                            margin: EdgeInsets.only(left: Constants.cardMargin),
                          // padding: EdgeInsets.all(40),
                            decoration: BoxDecoration(
                                color: Constants.cardColorCritical,
                                borderRadius: BorderRadius.all(Radius.circular(Constants.cardBorders))
                            ),
                          child: Column(
                            children: [
                              Text("212",style: Theme.of(context).textTheme.bodyText1,),
                              Text("Critical",style: Theme.of(context).textTheme.bodyText2,),
                            ],
                          )
                        ),
                      )
                    ],
                  ),
                ),
              ),
              SizedBox(height: 20,),
              Card(
                child: DataTable(
            sortAscending: isAscending,
            sortColumnIndex: sortColumnIndex,
                  columns: getColumns(columns),
            rows: getRows(users),
    ),
              )
            ],
          ),
        ),
      ),
    );
  }

  List<DataColumn> getColumns(List<String> columns) => columns
      .map((String column) => DataColumn(
    label: Text(column,style:GoogleFonts.nunito(fontSize: 18,color: Color(0xff1e224c),fontWeight: FontWeight.w600),),
    onSort: onSort,
  ))
      .toList();

  List<DataRow> getRows(List<Records> users) => users.map((Records user) {
    final cells = [user.id, user.department, user.open,user.completed,user.pending,user.closed];

    return DataRow(cells: getCells(cells));
  }).toList();

  List<DataCell> getCells(List<dynamic> cells) =>
      cells.map((data) => DataCell(Text('$data',style: GoogleFonts.nunito(fontSize: 15,color: Colors.black),))).toList();


  void onSort(int columnIndex, bool ascending) {
    if (columnIndex == 0) {
      users.sort((user1, user2) =>
          compareString(ascending, user1.id, user2.id));
    } else if (columnIndex == 1) {
      users.sort((user1, user2) =>
          compareString(ascending, user1.department, user2.department));
    } else if (columnIndex == 2) {
      users.sort((user1, user2) =>
          compareString(ascending, '${user1.open}', '${user2.open}'));
    } else if (columnIndex == 3) {
      users.sort((user1, user2) =>
          compareString(ascending, '${user1.completed}', '${user2.completed}'));
    } else if (columnIndex == 4) {
      users.sort((user1, user2) =>
          compareString(ascending, '${user1.pending}', '${user2.pending}'));
    } else if (columnIndex == 5) {
      users.sort((user1, user2) =>
          compareString(ascending, '${user1.closed}', '${user2.closed}'));
    }




    setState(() {
      this.sortColumnIndex = columnIndex;
      this.isAscending = ascending;
    });
  }

  int compareString(bool ascending, String value1, String value2) =>
      ascending ? value1.compareTo(value2) : value2.compareTo(value1);

}
