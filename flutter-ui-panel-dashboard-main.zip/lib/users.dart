

import 'package:admin_panel_responsive_flutter/models/User.dart';

final allUsers = <Records>[
Records(id: "1",department: "Revenue",open: 38,completed: 3,pending: 2,closed: 20),
Records(id: "2",department: "Cost",open: 40,completed: 23,pending: 6,closed: 30),

];
